
import time
import random


def bubbleSort(arr):
    n = len(arr)
    swaps = 0  # Initialize swap count
    for i in range(n - 1):
        for j in range(0, n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swaps += 1  # Increment swap count
    return swaps
def selectionSort(arr):
    n = len(arr)
    swaps = 0  # Initialize swap count
    for i in range(n):
        min_index = i
        for j in range(i + 1, n):
            if arr[j] < arr[min_index]:
                min_index = j
        arr[i], arr[min_index] = arr[min_index], arr[i]
        if min_index != i:  # If a swap occurred
            swaps += 1  # Increment swap count
    return swaps


# Function to measure the execution time of sorting algorithms
def measure_time(sort_function, arr):
    start_time = time.time()
    swaps = sort_function(arr)
    end_time = time.time()
    return swaps, end_time - start_time


# Function to generate a random array of given size
def generate_random_array(size):
    return [random.randint(1, 1000) for _ in range(size)]


# Define the sizes of arrays to test
sizes = [10, 50, 100, 500, 1000]

# Perform the comparison
for size in sizes:
    arr = generate_random_array(size)

    bubble_swaps, bubble_time = measure_time(bubbleSort, arr.copy())
    selection_swaps, selection_time = measure_time(selectionSort, arr.copy())

    print(f"For array size {size}:")
    print("\tBubble Sort:")
    print(f"\t\tNumber of Swaps: {bubble_swaps}")
    print(f"\t\tTime Taken: {bubble_time:.6f} seconds")
    print("\tSelection Sort:")
    print(f"\t\tNumber of Swaps: {selection_swaps}")
    print(f"\t\tTime Taken: {selection_time:.6f} seconds")
    print()
